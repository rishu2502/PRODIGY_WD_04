// scripts.js
document.addEventListener('DOMContentLoaded', function() {
    // Any JavaScript code if needed
});
